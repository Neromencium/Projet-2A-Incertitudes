##################
# Début de l'en-tête.
# Normalement, vous n'aurez jamais rien à modifier dans cette partie.
cmake_minimum_required( VERSION 3.5 ) # For older versions
#cmake_minimum_required( VERSION 4.0 )

project( EMM7_PROG1_TP3 VERSION 2026 )

set(CMAKE_CXX_STANDARD 17)       # C++17
set(CMAKE_CXX_STANDARD_REQUIRED ON)  # Enforce standard
set(CMAKE_CXX_EXTENSIONS OFF)      # Disable compiler extensions (e.g., GNU extensions)

set( LIBRARY_PATH_EIGEN "~/libraries/eigen/" )
set( LIBRARY_PATH_TOML "~/libraries/toml/" )

# Le répertoire dans lequel sont mis les exécutables
set( CMAKE_RUNTIME_OUTPUT_DIRECTORY "build/" )

# Spécifie les options passées au compilateur. Ici : l'optimisation du code binaire et les warnings.
set( CMAKE_CXX_FLAGS "-Wall" )
# set( CMAKE_CXX_FLAGS_DEBUG "-g" ) # Les paramètres par défaut en "debug": décommentez si vous voulez les changer
# set( CMAKE_CXX_FLAGS_RELEASE "-O3 -DNDEBUG" ) # Les paramètres par défaut en "release": décommentez si vous voulez les changer

# Options diverses de Cmake, à ne pas modifier.
set( CMAKE_SKIP_INSTALL_RULES True )

# Fin de l'en-tête
##################

##################
# Options spécifiques à ce projet.

# Décommentez la ligne que vous souhaitez, puis recompilez.
set( CMAKE_BUILD_TYPE "Debug" )
# set( CMAKE_BUILD_TYPE "Release" )

# Nom de l'exécutable qui sera créé dans le répertoire "build/".
# Nous ajoutons "Debug" ou "Release" au nom de l'exécutable afin de facilement les différencier.
# N'oubliez pas d'exécuter le fichier binaire correspondant que vous souhaitez !
set( TARGET_NAME "tp3_ode_${CMAKE_BUILD_TYPE}" )

# Recherche automatique de tous les fichiers '.cpp' du répertoire. => PROJECT_COMPILATION_FILE_LIST
FILE( GLOB PROJECT_COMPILATION_FILE_LIST "src/*.cpp" )
# Ou bien : liste *exhaustive* des fichiers à compiler.
# set( PROJECT_COMPILATION_FILE_LIST src/main.cpp src/Parameters.cpp src/OdeSystem.cpp src/TimeScheme.cpp )

# Précise que l'exécutable sera à assembler avec ces fichiers compilés.
add_executable( ${TARGET_NAME} ${PROJECT_COMPILATION_FILE_LIST} )

# Ajoute les répertoires des bibliothèques liées, ici Eigen et toML.
target_include_directories( ${TARGET_NAME} PUBLIC "${LIBRARY_PATH_EIGEN}" "${LIBRARY_PATH_TOML}" )

# Fin des options spécifiques à ce projet.
##################

#################
## Rappels et notes
#
# - Pour générer le fichier 'Makefile', lancez "cmake .".
# - Pour compiler votre code, lancez simplement "make".
# - Pour compiler votre code sur plusieurs process en parallèle, lancez "make -j 2" (pour 2 process, ou plus !).
# - Pour voir en détail les commandes de compilations qu'exécute "make", lancez "make VERBOSE=1".
# - Pour nettoyer votre répertoire de compilation, lancez "make clean".
#################
