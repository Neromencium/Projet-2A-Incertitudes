
set grid

plot        "results/test.dat" u 1:(exp($1)*1.0) w l t "Solution analytique" lw 2
replot      "results/test.dat" u 1:2 w lp t "Solution numérique"

pause -1 "Appuyer sur une touche pour continuer"
