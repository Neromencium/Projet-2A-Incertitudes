#include "VF.h"

double Schema_Rosanov::CFL_i(const int i)
{
    const double g = 9.81;   // intensité de pesanteur

    int nb_lignes = U_n.rows();

    if (i == 0 || i == nb_lignes - 1 )
    {
        std::cout << "Ne pas prendre les mailles du bord" << std::endl ; // U_0 et U_n+1 seront calculés après : U_0 = -U_1 et U_n+1 = U_n 
    }

    //Calcul des valeurs propres de U_G lambda_1/2 = q/h -/+ sqrt(gh)

    double k_g = std::sqrt(g*U_n(0,i-1));
    double lambda_1 = U_n(1,i-1)/U_n(0,i-1) - k_g;     
    double lambda_2 = U_n(1,i-1)/U_n(0,i-1) + k_g;     

    //Calcul des valeurs propres de U_D mu_1/2 = q/h -/+ sqrt(gh)

    double k_d = std::sqrt(g*U_n(0,i+1));
    double mu_1 = U_n(1,i-1)/U_n(0,i+1) - k_d;     
    double mu_2 = U_n(1,i-1)/U_n(0,i+1) + k_d;   

    double c_i = std::max({lambda_1, lambda_2, mu_1, mu_2});

    return c_i;

}


Eigen::Vector2d Schema_Rosanov::flux_num(const int i) // prend en entrée i, n, U_n, et renvoit F^{n}_{i+1/2}
{

    double c_i = CFL_i(i);  //Attention on ne prend que i allant de 1 à n, U_0 et U_n+1 sont calculés à part, U_n+1 = U_n et U_0 = - U_1
    Eigen::Vector2d F_i = ((fonction_flux(U_n.col(i+1)) + fonction_flux(U_n.col(i)))/2) - c_i*(U_n.col(i+1) - U_n.col(i)/2) ;
    
}


Eigen::Vector2d fonction_flux(Eigen::Vector2d U)   // Attention ici U est un vecteur 2D par une matrice
{
    const double g = 9.81;   // intensité de pesanteur
    double f_q = (U(1)*U(1) / U(0)) + (g*U(0)*U(0) / 2);     //Seconde coordoonée de f_U
    Eigen::Vector2d f_U (U(1), f_q);     //  f_U est l'image de U par fonction_flux  //À finir voire formule page 2/14 article rouge

    return f_U;

}


Eigen::Vector2d Schema_Rosanov::topo(const int i, const Parameters & params ) //Renvoit S_i_n : le sol pour la maille i à l'instant n
{
    const double g = 9.81;   // intensité de pesanteur
    Eigen::Vector2d S_i_n;
    if (i==params.nx) { 
        S_i_n =  {0.0, (-g* (params.z(i) - params.z(i-1)) )/params.dx};    // On a fait une différence finie simple décentrée à gauche
    } else {
        S_i_n = {0.0, (-g* (params.z(i+1) - params.z(i)) )/params.dx};    // On a fait une différence finie simple décentrée à droite
    }
    return S_i_n;
}

void Schema_Rosanov::sol_num(const Parameters & params)   // fonction qui prend en entrée la solution U_n et renvoit la solution U_n+1
{
    int n = U_n.rows() -1;
    for (int i = 1; i<=n; i++)
    {
        U_n.col(i) = U_n.col(i) - (params.dt /params.dx) * (flux_num(i+1) - flux_num(i-1)) + params.dt * topo(i, params);
    }
    CL(U_n, params);
}



void Schema_Rosanov::update_dt(const Parameters & params)
{
    double c = -10;
    for (int i=1; i<=params.nx; i++)
    {
    c = std::max(c, CFL_i(i));
    }

    params.update_dt_iterations(params.cfl*(params.dx /c));

}




Schema_VF * create_VF_scheme(const Parameters & params) {
    Schema_Rosanov * schema = new Schema_Rosanov();
    schema->U_n.row(0) = params.h_0;	// Init matrice
    schema->U_n.row(1) = params.u_0;
    return schema;
}