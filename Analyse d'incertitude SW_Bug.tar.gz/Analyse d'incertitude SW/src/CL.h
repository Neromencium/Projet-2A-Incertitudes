#ifndef _CL_H
#define _CL_H

#include "Parameters.h"
#include <toml11/single_include/toml.hpp>
#include <iostream>

void CL(Eigen::MatrixXd & U, const Parameters & params);

#endif