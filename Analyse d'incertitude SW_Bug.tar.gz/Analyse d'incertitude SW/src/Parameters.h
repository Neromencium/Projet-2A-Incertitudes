/**
* Une classe qui stocke/encapsule les différents paramètres du code de calcul.
* Cette classe pourrait être remplie depuis un fichier de paramètres.
**/

#ifndef _PARAMETERS_H
#define _PARAMETERS_H

#include <string>
#include <iostream>
#include <Eigen/Dense>
#include <toml11/single_include/toml.hpp>

class Parameters
{
   public:
   double t_final = 0.0;             // Temps final
   double dx = 0.0;                  // Pas en espace
   double dt = 0.0;                  // Pas de temps
   int nx = 0;                       // Nombre de mailles
   double Lx = 1.0;                  // Longueur du domaine
   double cfl = 1.0;


   Eigen::VectorXd x;             // Coordonnées des mailles
   Eigen::VectorXd h_0;           // Hauteurs d'eau
   Eigen::VectorXd u_0;           // Vitesses
   Eigen::Matrix2Xd U;            // Matrice dans laquelle on va travailler
   Eigen::VectorXd z;             // Topographie
   

   std::string output = "";           // Nom du fichier de sortie ; "" pour aucun
   std::string mode = "integration";     // Mode d'exécution ?
   std::string test = "resaut";
   bool debug = false;                // Affichage du debug ?
   
   std::string integrator_name = "Euler";      // Schéma d'intégration
   
   // Attributs calculés automatiquement :
   unsigned int n_iterations = 0;              // Nombre d'itérations
   bool save_output = false;                   // Enregistrement du fichier de sortie
   
   // Construit les paramètres à partir du nom de fichier
   void read_from_file( const std::string & filename );
   // Affiche le contenu de la classe vers l'output (par défaut : std::cout), comme par exemple un fichier.
   void print( std::ostream & output = std::cout ) const;
   
   // Doit être appelé pour mettre à jour le nombre d'itérations si dt ou t_final a été modifié
   void update_dt_iterations(const double dt);

   void init_scheme();
   
   toml::value tomlfile;        // La structure de données lue par toML pour utilisation ultérieure
};

#endif