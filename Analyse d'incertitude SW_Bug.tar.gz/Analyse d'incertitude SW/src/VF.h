#ifndef VF_H
#define VF_H

#include <Eigen/Dense>
#include <iostream>
#include <cmath>
#include <algorithm>
#include "Parameters.h"
#include "CL.h"

class Schema_VF {
    public :
        Eigen::MatrixXd U_n;   // Solution à l'instant n 
        // Il serait bien de modifier dt de params dans sol_num 
        
        Schema_VF();
        ~Schema_VF();

        virtual void init( const unsigned int N );
        virtual double CFL_i(const int i)=0;  // renvoit la condition CFL pour pour la maille i à partir des vecteurs U^{n}_i et U^{n}_i+1
        virtual void update_dt(const Parameters & params)=0;
        virtual Eigen::Vector2d flux_num(const int i)=0; // prend en entrée i, n, U_n, et renvoit F^{n}_{i+1/2}

        virtual void sol_num(const Parameters & params)=0;   // fonction qui prend en entrée la solution U_n et renvoit la solution U_n+1


        

};



class Schema_Rosanov: public Schema_VF {

    public:

        double CFL_i(const int i);  // renvoit la condition CFL pour pour la maille i à partir des vecteurs U^{n}_i et U^{n}_i+1

        Eigen::Vector2d flux_num(const int i); // prend en entrée i, n, U_n, et renvoit F^{n}_{i+1/2}

        Eigen::Vector2d topo(const int i, const Parameters & params ); //Renvoit S_i_n : le sol pour la maille i à l'instant n

        void sol_num(const Parameters & params);   // fonction qui met à jour U_n

        void update_dt(const Parameters & params);

    
};


Eigen::Vector2d fonction_flux(Eigen::Vector2d U);   // Attention ici U est un vecteur 2D par une matrice

Schema_VF * create_VF_scheme( const Parameters & params );


#endif
