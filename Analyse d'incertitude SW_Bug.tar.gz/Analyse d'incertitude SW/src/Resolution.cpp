#include "Resolution.h"

Eigen::VectorXd integrate_ode( const Parameters & params)
{
	/*************************
	* 1 - Initialisation et lecture du fichier de sortie
	*************************/
	double t = 0.0;
	unsigned int it = 1;
	Schema_VF * schema = create_VF_scheme(params);
    
	schema->update_dt(params); // init dt
	std::ofstream file; // Éventuel fichier de sortie
	
	if (params.save_output) {
		file = std::ofstream( params.output );
		if (!file) {
			std::cerr << "Can't open file " << params.output << " for output! (please check that the destination directory exists)" << std::endl;
			exit(-3);
		}
		params.print( file ); // Écrit les paramètres en commentaires dans le fichier de résultats
		file << t << "\t" << schema->U_n.row(0).transpose().format(FullFormat) << "\t" << schema->U_n.row(1).transpose().format(FullFormat) << std::endl;
	}
	
	/*************************
	* 2 - Itérations du schéma numérique jusqu'au temps final
	*************************/
	while (t < params.t_final) {
		if (params.debug) { std::cout << "Iteration #" << it << ": t=" << t << "->" << t+params.dt << std::endl; }
		
		// Intégration d'un pas de temps -> Solution stockée dans 'X_n'
		schema->sol_num(params); // Mise à jour du schéma 
        schema->update_dt(params); // Mise à jour de dt
		
		if (params.debug) { std::cout << "\tSolution h : " << schema->U_n.row(0).transpose() << std::endl; }
		if (params.debug) { std::cout << "\tSolution u : " << schema->U_n.row(1).transpose() << std::endl; }
		
		if (params.save_output) {
			file << t+params.dt << "\t" << schema->U_n.row(0).transpose().format(FullFormat) << "\t" << schema->U_n.row(1).transpose().format(FullFormat) << std::endl;
		}
		
		t += params.dt;
        it += 1;
	}
	
	/*************************
	* 3 - Fermeture du flux
	*************************/
	if (file) {
		file.close();
	}
	
	return schema->U_n;
}