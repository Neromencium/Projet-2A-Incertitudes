#include <Eigen/Dense>
#include "Parameters.h"
#include "VF.h"

// Utile pour l'affichage aligné des résultats dans le fichier
Eigen::IOFormat FullFormat(Eigen::FullPrecision,Eigen::DontAlignCols,"\t");

Eigen::VectorXd integrate_ode( const Parameters & params, Schema_VF * schema);