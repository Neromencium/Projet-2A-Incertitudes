#include "CL.h"

void CL(Eigen::MatrixXd & U, const Parameters & params) {
    // V1 : Cl dirichlet nulle à gauche et Neumann à droite nulle (voir [3] p 45)
    U(0, params.nx+1) = U(0, params.nx); // Dérivée nulle à l'extrémité droite grâce à la cellule fantôme
    U(1, params.nx+1) = U(1, params.nx);
    U(0, 0) = -U(0, 1); // Comme ça, en 0 on a une vitesse nulle, 0 étant une maille fantôme
    U(1, 0) = -U(1, 1);
}